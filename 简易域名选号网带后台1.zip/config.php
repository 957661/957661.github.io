<?php
// 简易后台配置
define('ADMIN_USERNAME', 'admin');       // 用户名（可改）
define('ADMIN_PASSWORD', 'admin123');    // 密码（请务必修改为强密码！）

// 允许的来源域名（可选，用于简单防CSRF），留空数组表示不限制
$ALLOWED_ORIGINS = [];